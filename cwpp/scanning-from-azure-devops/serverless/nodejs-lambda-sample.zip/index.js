const fetch = require('node-fetch');

const url = 'https://api3.prismacloud.io/check';
const options = {method: 'GET', headers: {Accept: 'application/json; charset=UTF-8'}};

exports.handler =  function(event, context, callback) {
	fetch(url, options)
		.then(res => res.json())
		.then(json => console.log(json))
		.catch(err => console.error('error:' + err));
}